from flask import Flask, render_template, request, redirect, url_for, session
import psutil

app = Flask(__name__, static_url_path='/static')
app.secret_key = 'your_secret_key'

# Define a dictionary to store valid usernames and passwords
users = {
    'farooq': 'ALLAH@786'
}

# Define a dictionary to store system information (for demonstration purposes)
system_info = {
    'memory_percentage': 0,
    'disk_usage': 0,
    'host_ip': '127.0.0.1',
    'hostname': 'localhost'
}

@app.route('/')
def login_redirect():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username] == password:
            # Store the username in the session
            session['username'] = username
            return redirect(url_for('home'))
        else:
            return render_template('login.html', title='Login', message='Invalid username or password')
    return render_template('login.html', title='Login')

@app.route('/home')
def home():
    # Check if user is logged in
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('index.html', title='Home')

@app.route('/system-info')
def system_info():
    # Check if user is logged in
    if 'username' not in session:
        return redirect(url_for('login'))
    
    # Get system information only if user is logged in
    memory_percentage = psutil.virtual_memory().percent
    disk_usage = psutil.disk_usage('/').percent
    host_ip = '127.0.0.1'  # Replace with a more secure method to get host IP
    hostname = 'localhost'  # Replace with a more secure method to get hostname

    # Store system information in the session
    session['system_info'] = {
        'memory_percentage': memory_percentage,
        'disk_usage': disk_usage,
        'host_ip': host_ip,
        'hostname': hostname
    }

    return render_template('system_info.html', title='System Information',
                           memory_percentage=memory_percentage,
                           disk_usage=disk_usage, host_ip=host_ip, hostname=hostname)

@app.route('/logout')
def logout():
    # Remove the username and system_info from the session if they're there
    session.pop('username', None)
    session.pop('system_info', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)

